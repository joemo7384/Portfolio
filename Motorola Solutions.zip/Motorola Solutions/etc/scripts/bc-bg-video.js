
    /*** Brightcove Background Video Player for Hero Video Block ***/
    var playerCont = $('#background-video');
    var bgid = 'background-video';
    function buildBackgroundPlayer(){
        var thats = this,
        myBgPlayer,
        playerHTML,
        playerData = {
            "accountId": '81597806001',
            "playerId" : "default",
            "videoId" : '5989300849001'
        }
        // dynamically build the player video element
        playerHTML = '<video id=\"background-video\" data-video-id=\"' + playerData.videoId + '\"  data-account=\"' + playerData.accountId + '\" data-player=\"' + playerData.playerId + '\" data-embed=\"default\" class=\"video-js\" autoplay></video>';
        
        // inject the player code into the DOM
        playerCont.html(playerHTML);
        
        // instantiate player
        bc(document.getElementById(bgid));

        videojs(bgid).ready(function(){
            myBgPlayer = playerCont;
            myBgPlayer.on("ended", function () {
                myBgPlayer.play();
            });
        });    
    }                            
    buildBackgroundPlayer();
