  $(document).ready(function(){
                
                $(".proxy_button").click(function(){
                 $("i").toggleClass("up");   
                  $("#proxy-show").fadeToggle('slow');       
                });   

        $(".submit_id").click(function(){
      $(this).attr("value","END PROXY");    
      });   

      //THIS CODE FOR TYPEAHEAD AND JSON INTEGRATION
      $.getJSON('/app/etc/assets/json/SampleUsersSearch.json', function(data) {
        var jsonData = data;
      // Defining the local dataset
      //using fat arrow functions (=>) raises issues in ie 11
      var login_email = jsonData.data.map(function(i){ return i.login_id});
      
      // Constructing the suggestion engine
      var login_email = new Bloodhound({
          datumTokenizer: Bloodhound.tokenizers.whitespace,
          queryTokenizer: Bloodhound.tokenizers.whitespace,
          local: login_email
      });
      
      // Initializing the typeahead
      $('.typeahead').typeahead({
          hint: true,
          highlight: true, /* Enable substring highlighting */
          minLength: 1 /* Specify minimum characters required for showing suggestions */
      },
      {
          name: 'login_email',
          source: login_email
      });
    });
  });
