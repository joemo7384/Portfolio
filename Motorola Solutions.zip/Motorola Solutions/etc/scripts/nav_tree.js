'use strict';

msiObj.controllers.nav_tree = {
  init: function () {
    var that = this;
    this.backBtn = $('.ms-nav-back');
    this.pageLink = $('.active > a');
    this.navTree = $('.ms-nav-tree');
    this.isOpen = true;
    this.userClose = false;
    this.viewport = msiObj.utils.getEl('ms_viewport', '#', true);

    $(window).on('resizeWin', function(e, val, change){
      that.handleWinResize(val);
    });
    this.handleWinResize(msiObj.bindings.windowSize);

  },
  handleWinResize: function (val) {
    if (val > 0) {
      this.bindSmall(false);
      this.userClose = true;
      this.closeMenu();
    } else {
      this.bindSmall(true)
      // if (this.isOpen) {
      //   this.openMenu();
      // }
    }
  },
  bindSmall: function (val) {
    var that = this;
    if (val) {
      // SET UP HASH CHANGE TRACKING
      $(window).on('hashchange.navtree', function(e){
        that.handleHashChange(location.hash);
      });
      // Detect and run initial hash
      that.handleHashChange(location.hash);

      this.backBtn.on('click', function(e) {
        e.preventDefault();
        that.userClose = false;
        if (location.hash) {
          document.location.hash = '';
        } else {
          that.openMenu();
        }
      });

      this.pageLink.on('click', function(e) {
        e.preventDefault();
        that.userClose = true;
        document.location.hash = 'nav-tree-close';
      });
    } else {
      this.backBtn.unbind('click');
      this.pageLink.unbind('click');
      $(window).unbind('.navtree');
      this.closeMenu();
    }
  },
  handleHashChange: function (hash) {
    if (hash && hash == '#nav-tree-close') {
      this.closeMenu();
    } else if (!this.userClose) {
      this.openMenu();
    }
  },
  openMenu: function () {
    msiObj.utils.unflowViewport(true, 'ms-nav-tree');
    this.navTree.removeClass('nav-closed');
    this.isOpen = true;
    msiObj.container.trigger('nav-tree-open', [true]);
    this.viewport.addClass('disp-sm-foot');
  },
  closeMenu: function () {
    msiObj.utils.unflowViewport(false, 'ms-nav-tree');
    this.navTree.addClass('nav-closed');
    this.isOpen = false;
    msiObj.container.trigger('nav-tree-open', [false]);
    this.viewport.removeClass('disp-sm-foot');
  }
}