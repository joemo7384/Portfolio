'use strict';

if (typeof jQuery === "undefined") {
 throw "This widget requires jquery module to be loaded";
}

var header;

$(document).ready(function(){
  header = $('header');
});
(function($){
  var myObj = {
    options: {
    },
    /************************
    *    PRIVATE METHODS    *
    *************************/
    _init : function(){
    },
    _create : function(){
      var that = this
      this.hideFunc = this.hidecss,
      this.showFunc = this.showcss;
      this.inTimer = null;
      this.outTimer = null;
      this.bound = false;
      this.open = false;
        this.clickCount = 0;
      this.$flyout = this.element.find('.nav-flyout');
      this.$cover = this.element.find('span');

    	// reset hide show function if tranistions not supported
    	if (!Modernizr.csstransitions) {
    		this.hideFunc = this.hidejs;
    		this.showFunc = this.showjs;
    	}

    	// bind mouse over
    	this.element.on('mouseenter', function (e) {
  			clearTimeout(that.outTimer);
  			that.inTimer = setTimeout(
  				function () {
  					that.handleOpenDrawer();
  			}, 100);
  		});

    	// bind mouse leave
  		this.element.on('mouseleave', function (e) {
  			clearTimeout(that.inTimer);
  			that.outTimer = setTimeout(
  				function () {
						that.closeFlyout();
  				}, 100);
  		});

      if(typeof window.orientation != 'undefined') {
        var w = $(window).width();
        window.addEventListener("orientationchange", function() { 
            w=$(window).width();    
            if (w>984) {
        that.element.children('a').on('click', function (e) {
          if (that.clickCount<1) {
            e.preventDefault();
            that.clickCount++;
            that.handleOpenDrawer();
          }
        });
      } else if (w<984) {
       that.element.children('a').unbind('click');
      }
        }, false);
        if (w>984) {  
        this.element.children('a').on('click', function (e) {
          if (that.clickCount<1) {
            e.preventDefault();
            that.clickCount++;
            that.handleOpenDrawer();
          }
        });
      } else if (w<984) {
          this.element.children('a').unbind('click');
      }
      }
    },
    handleOpenDrawer: function () {
      if (!this.open && !header.hasClass('collapsed')) {
        this.open = true;
        //trigger nav-flyout-open function that closes search and buddy if they are open
        msiObj.container.trigger('nav-flyout-open');
        $('select').blur(); // Blur all select menus
       // close search helper for IE
       if (!Modernizr.csstransitions) {
            if($(".ms-search-pane").is(":visible")) { 
                $(".ms-search-pane").delay(100).fadeOut(); 
                msiObj.data.navToggle = false; } 
       }
        this.showFunc(this);
        this.bindDocClick();
      }
    },
    bindDocClick: function () {
      var that = this;
      $(document).on('click.flyout touchstart.flyout', function (e) {
        if($(e.target).parents('#nav_links').length<1) {
         that.closeFlyout();
        }
      });
    },
    unbindDocClick: function () {
      $(document).unbind('click.flyout touchstart.flyout');
    },
    closeFlyout: function () {
      if(this.open) {
        this.open = false;
        this.unbindDocClick();
        this.hideFunc(this);
        this.element.removeClass('anim-in');
        this.clickCount = 0;
      }
    },
    showcss: function (ctx) {
      ctx.element.addClass('anim-in show-fly');
    },
    showjs: function (ctx) {
    	ctx.element.addClass('show-fly');
			ctx.$cover.css('bottom', -1);
			ctx.$flyout.css({'z-index': 1, 'margin-top': '-500px'}).animate({'margin-top':0},500);
    },
    hidecss: function (ctx) {
    	ctx.removeAnim();
    },
    hidejs: function (ctx) {
				ctx.element.removeClass('show-fly');
        ctx.$cover.removeAttr('style');
        ctx.$flyout.removeAttr('style');
    },
    removeAnim: function (el) {
	  	if (!this.open) {
		  	this.element.removeClass('show-fly')
		  }
	  }
 };

  $.widget( 'ui.nav_links', myObj );
})(jQuery);

// initialize the controller
msiObj.controllers.nav_links = {
  init: function () {
    this.$element = msiObj.utils.getEl('nav_links', 'id', true);
  	this.$links = this.$element.children('.hassub');
    $( this.$links ).nav_links();
  }
}