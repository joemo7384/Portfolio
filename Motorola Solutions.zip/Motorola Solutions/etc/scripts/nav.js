'use strict';
var navElement = {};
$(document).ready(function() {
  navElement.navArea = $('#ms-nav-main');
  navElement.navLinks = $('#nav_links').outerWidth() + 30;
  navElement.navUtil = $('#ms-nav-util').outerWidth(true);
  navElement.navSearch = $('#nav-search').outerWidth(true);
  navElement.navGlobalIcons = $('.global-icons').outerWidth(true);
  navElement.header = $('header');
  navElement.links = $('#nav_links');
  navElement.spaceNeeded = navElement.navLinks + navElement.navUtil + navElement.navSearch;
  navElement.isCollapsed = navElement.header.hasClass('collapsed');
  toggleCollapsedNav(checkSpace());
  // console.log('util space: '+(+navElement.navUtil));
  $('#nav_links').css('white-space','normal');

});

// KMS code to prevent the nav from hiding overflow on scroll
console.log('nav.js resizing window');
  if($(window).width < 767) {
    console.log('made it past the if');
    $(window).resize(function() {
    if(navElement.header && !($('body').hasClass('sidenav-active') || $('body').hasClass('buddynav-active'))) {
      // navElement.header.css('overflow','hidden');
    }
    clearTimeout(window.resizedFinishedHeader);
    window.resizedFinishedHeader = setTimeout(function() {
        toggleCollapsedNav(checkSpace());
        setTimeout(function(){if(navElement.header){navElement.header.css('overflow','visible');}},500);
    }, 400);
  })
};

// FUNCTION TO CALC IF COLLAPSED IS NEEDED
function checkSpace(){
  // console.log('-----INSTANCE---------------------------------------');
  // console.log('nav links: '+ +navElement.navLinks);
  // console.log('util space: '+(+navElement.navUtil));
  // console.log('search space: '+(+navElement.navSearch));
  // console.log('icon space: '+(+navElement.navUtil + +navElement.navSearch));
  // console.log('**SPACE NEEDED: '+ +navElement.spaceNeeded);
  // console.log('header width: '+(+navElement.header.outerWidth() - 40));
  // console.log('global-icons: '+(+navElement.navGlobalIcons));
  // console.log('**header SPACE FREE: '+(+navElement.header.outerWidth() - (321 + +navElement.navGlobalIcons)));
  // console.log('**TRUE header SPACE FREE: '+(+navElement.header.find('.ms-site-cont').outerWidth() - (321 + +navElement.navGlobalIcons)));
  
  // console.log('SPACE AVAILABLE: '+(+navElement.navArea.outerWidth()));
  // var needsCollapsed = (+navElement.spaceNeeded > (+navElement.header.outerWidth() - (321 + +navElement.navGlobalIcons))) ? true : false;
  var needsCollapsed = (+navElement.spaceNeeded > (+navElement.header.find('.ms-site-cont').outerWidth() - (321 + +navElement.navGlobalIcons))) ? true : false;
  // console.log('needsCollapsed: '+needsCollapsed);
  // console.log('-----INSTANCE END------------------------------------');
  return needsCollapsed;
}
// FUNCTION TO COLLAPSE MAIN NAV BASED ON BOOL PASSED
function toggleCollapsedNav(val) {
    // console.log('running toggle');
    if(val && !navElement.header.hasClass('collapsed')){
      // navElement.navArea.css('visibility','hidden');
    }
    else if(!val){
      msiObj.container.trigger('sidenav', [false,'sidenav']);
    }
    var toDo = (val) ? 'addClass' : 'removeClass';
    // adds or removes collapsed class based on bool passed set to toDo
    navElement.header[toDo]('collapsed');
    // updates isCollapsed
    navElement.isCollapsed = (val) ? true : false;
    // RUN HEIGHT ADJUSTMENT FUNCTION IN HEADER.JS TO SET THE HEIGHT ON THE SLIDE OUT NAV
    adjustSlideoutHeight();
    // if nav is collapsed remove active class from search icon
    if(navElement.isCollapsed && $('#search-toggle').hasClass('active')){
        // console.log('ran first check---');
        // console.log('clicked');
        $('#search-toggle').click();
    }
    setTimeout(function(){navElement.navArea.css('visibility','visible');},300);
    // navElement.navArea.css('visibility','visible');
}
msiObj.controllers.nav = {
  init: function () {
    var that = this;
    this.$nav = msiObj.utils.getEl('ms-nav-main', 'id');
    // set the value of the sidenav to false if it doesn't exist.
    msiObj.data.sidenav = (msiObj.data.sidenav) ? msiObj.data.sidenav : false;

    $(window).on('resizeWin', function(e, val, change) {
      // don't do anything unless the drawer is out
      if (!msiObj.data.sidenav) { return false; }
      if (val > 1 ) {
        // on resize if grow above mobile reflow
        that.toggleNav(false);
      }
    });

    // assign the toggle and trigger a side nav event on click
    var $toggle = msiObj.utils.getEl('nav_shade', 'id');
    $toggle.on('click', function (e) {
      msiObj.container.trigger('sidenav', [false,'sidenav']);
      // checkMenu();
    });

    // assign the toggle and trigger a side nav event on click
    var $toggle = msiObj.utils.getEl('main_nav_close', 'id');
    $toggle.on('click', function (e) {
      msiObj.container.trigger('sidenav', [false,'sidenav']);
      // checkMenu();
    });

    // assign the toggle and trigger a buddy nav event on click
    var $toggle = msiObj.utils.getEl('nav_shade_buddy', 'id');
    $toggle.on('click', function (e) {
      msiObj.container.trigger('sidenav', [false,'buddynav']);
      // checkMenu();
    });

    // assign the toggle and trigger a buddy nav event on click
    var $toggle = msiObj.utils.getEl('buddy_nav_close', 'id');
    $toggle.on('click', function (e) {
      msiObj.container.trigger('sidenav', [false,'buddynav']);
      // checkMenu();
    });

    // register for events
    msiObj.container.register(this, {
      'sidenav' : this.toggleNav
    });
  },
  toggleNav: function (val,navSelection) {
    var toDo = (val) ? 'addClass' : 'removeClass';
    msiObj.data.sidenav = val;
    msiObj.bindings.body[toDo](navSelection+'-active');
    msiObj.utils.unflowViewport(val, 'nav');
    msiObj.container.trigger('search-open');
  }
}