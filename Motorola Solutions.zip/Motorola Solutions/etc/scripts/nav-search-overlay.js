 /* Search Modal */
 $(document).ready(function() {
    $('#search-toggle').click(function(){
      $('#nav_search_modal').css('display', 'block');
      $('body').css('overflow', 'hidden');
      $(this).removeClass('active');
    });

    $('.CoveoCustomHideStandaloneSearchbox').click(function(){
      $('#nav_search_modal').css("display", "none");
      $('body').css('overflow', 'auto');
    });

    $('.CoveoSearchButton').click(function(){
      $('#nav_search_modal').css("display", "none");
      $('body').css('overflow', 'auto');
    });

  });

  $(document).keydown(function(e) { 
    if (e.keyCode == 27 || 13) { 
      $('#nav_search_modal').css("display", "none");
      $('body').css('overflow', 'auto');
    }
  });

  $(window).resize(function() {
    if ($(this).width() < 767) {
      $('#nav_search_modal').css("display", "none");   
    }
  });
