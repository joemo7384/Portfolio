'use strict';

var msiObj = {
  events: {},
  controllers: {},
  bindings: {},
  data: {},
  container: {
  	registry: {},
  	register: function (obj, handlers) {
  		for(var handler in handlers) {
  			if (this.registry[handler]) {
  				this.registry[handler].push({obj: obj, handler: handlers[handler]});
  			} else {
  				var tmp = handlers[handler];
  				this.registry[handler] = [{ obj: obj, handler: tmp }];
  			}
  		}
  	},
  	trigger: function (evt, args) {
      args = ( typeof(args) === 'undefined') ? [] : args;
  		var regevt = this.registry[evt];
  		if (regevt) {
	  		var i = 0,
	  			len = regevt.length,
          func;
	  		for (; i<len; i++) {
          func = regevt[i].handler;
          func.apply(regevt[i].obj, args)
	  		}
	  	}
  	}
  }
};