'use strict';
console.log('header.js loaded')
// vars
var cB;

msiObj.controllers.header = {
  init: function () {
    // set the value of the sidenav to false if it doesn't exist.
    msiObj.data.sidenav = (msiObj.data.sidenav) ? msiObj.data.sidenav : false;

    var $toggle = msiObj.utils.getEl('mobile-toggle', 'id');
    $toggle.on('click', function (e) {
      msiObj.container.trigger('sidenav', [!msiObj.data.sidenav,'sidenav']);
      if($('.ms-search-pane').is(":hidden")) { $(".ms-search-pane").show(); } 
    });
  }
}
// Open Banner
function noticeO() { 
    // console.log('NOTICEO');
    $(".ms-header-notice").show(); 
    $(".ms-header").css("height", "83px"); 
    // adjustSlideoutHeight();
    // Mobile
    if ($(window).width() < 984) { 
        $(".ms-content-main").css("margin","20px 0 0"); 
        $(".ms-hero-home").css("margin-top","20px"); 
        if ($(".ms-breadcrumbs").length || $(".ms-site-cont").find("h1").length) { 
            $(".ms-content-main").css("margin","24px 0 0");
            $(".ms-content-main-wide .ms-hero-home").css("margin-top","17px");
            $(".ms-content-main-wide .ms-breadcrumbs").css("padding-top","25px");
        }
        $(".notice-lock-lg").hide(); 
        $(".notice-lock-sm").show(); 
        $(".ms-anchorlink-content").css("margin-top","20px"); 
        $(".ms-tab-full").css("margin-top","20px"); 
        $("#anchorlnks_accessories .ms-tab-back").css("margin-top","20px");
        if ($(".product-catalog-selection").length) { $(".product-catalog-selection").css("top", "24px"); }
    // Desktop
    } else {
        if (!$(".ms-hero-home")[0]){ 
             $(".ms-content-main").css("margin","74px 0 0");   
        }
        if ($(".scf-site-header")[0]) {
            $(".scf-site-header").css("margin-top","0px");
        }

        $(".ms-hero-home").css("margin-top","71px");
        if ($(".ms-anchor-list")[0]){ 
            $('.ms-anchor-list').trigger('detach.ScrollToFixed');
            if (typeof window.orientation == 'undefined') { 
              // console.log('header.js noticeO anchor-list');
              var temp = $(".ms-header-notice").is(":visible") ? 86 : 63;
              $('.ms-anchor-list').scrollToFixed({ 
                marginTop:86, 
                limit: $('.ms-header-nav').offset(),
                unfixed: function(){
                  if($('body').hasClass('sidenav-active') || $('body').hasClass('buddynav-active')){
                    $(this).css({
                      'position':'fixed',
                      'top': temp
                    });
                  }
                } 
              }); 
            }
        }
        if ($(".ms-nav-horizontal")[0]){ 
            $('.ms-nav-horizontal').trigger('detach.ScrollToFixed');
            if (typeof window.orientation == 'undefined') { 
                $('.ms-nav-horizontal').scrollToFixed({ marginTop:74, limit: $('.ms-header-nav').offset() });
            }
            if (typeof window.orientation == 'undefined') {
                    if($(".ms-header-notice").is(":visible")) {
                        // console.log('header.js noticeO nav-horizontal -- with notice');
                        $('.ms-anchor-list').scrollToFixed({ marginTop:133, top: 0, limit: $('.ms-header-nav').offset() }); 
                    } else {
                        // console.log('header.js noticeO nav-horizontal -- without notice');
                        $('.ms-anchor-list').scrollToFixed({ marginTop:110, top: 0, limit: $('.ms-header-nav').offset() }); 
                    }  
                }
        }
        if ($(".ms-breadcrumbs").length || $(".ms-site-cont").find("h1").length) { 
            $(".ms-content-main").css("margin","74px 0 0");
            $(".ms-content-main-wide").css("margin","80px 0 0"); 
            $(".ms-content-main-wide .ms-hero-home").css("margin-top","17px");
            $(".ms-content-main-wide .ms-breadcrumbs").css("padding-top","40px");
        }
    $(".notice-lock-lg").show();
    $(".notice-lock-sm").hide();
    if ($(".product-catalog-selection").length) { $(".product-catalog-selection").css("top", "0px"); }
    } 
}

// Close Banner
function noticeC() {
    // console.log('NOTICEC');
    $(".ms-header-notice").hide(); 
    $(".ms-header").css("height", "60px"); 
    // $(".ms-nav-main").css("top","0px");
    // $(".ms-nav-buddy-menu.dss-user").css({"top":"0px",'height':window.innerHeight});
    
    // adjustSlideoutHeight();
    if ($(".product-catalog-selection").length) { $(".product-catalog-selection").css("top", "0px"); }
    // Mobile
    if ($(window).width() < 984) {
        $(".ms-hero-home").css("margin-top","0px"); 
        if ($(".ms-breadcrumbs").length || $(".ms-site-cont").find("h1").length) { 
            $(".ms-content-main-wide").css("margin","0px 0 0"); 
            $(".ms-content-main-wide .ms-hero-home").css("margin-top","10px");
            $(".ms-content-main-wide .ms-breadcrumbs").css("padding-top","20px");
        }
        if (!$('.ms-breadcrumbs').is(':visible')) {
            $(".ms-content-main-wide").css("margin","15px 0 0"); 
        }
        $(".ms-anchorlink-content").css("margin-top","0px");
        $(".ms-tab-full").css("margin-top","0px"); 
        $("#anchorlnks_accessories .ms-tab-back").css("margin-top","0px");
        if ($(".ms-nav-horizontal").length) { $('.ms-nav-horizontal').trigger('detach.ScrollToFixed'); }
        if (!$(".ms-hero-home")[0]){ 
            $(".ms-content-main").css("margin","0px 0 0"); 
        }
    // Desktop
    } else {
        if ($(".product-catalog-selection").length) { $(".product-catalog-selection").css("top", "0px"); }
        if ($(".scf-site-header")[0]) {
             $(".scf-site-header").css("margin-top","0px");   
        }
         if ($(".ms-hero-home-sm")[0]){
            $(".ms-breadcrumbs-integrated").css("margin-top","0px");
        }

        $(".ms-hero-home").css("margin-top","51px"); 
        if ($(".ms-breadcrumbs").length || $(".ms-site-cont").find("h1").length) { 
            $(".ms-content-main-wide .ms-hero-home").css("margin-top","17px");
            $(".ms-content-main-wide .ms-breadcrumbs").css("padding-top","20px");
        }
        if ($(".ms-anchor-list")[0]){ 
            $('.ms-anchor-list').trigger('detach.ScrollToFixed');
            if ($('.ms-nav-horizontal').length) {
                if (typeof window.orientation == 'undefined') {
                    if($(".ms-header-notice").is(":visible")) {
                        // console.log('header.js noticeC nav-horizontal -- with notice');
                        $('.ms-anchor-list').scrollToFixed({ marginTop:125, top: 0, limit: $('.ms-header-nav').offset() }); 
                    } else {
                        // console.log('header.js noticeC nav-horizontal -- without notice');
                        $('.ms-anchor-list').scrollToFixed({ marginTop:110, top: 0, limit: $('.ms-header-nav').offset() }); 
                    }  
                }
            } else {
                if (typeof window.orientation == 'undefined') { 
                  // console.log('header.js noticeC nav-horizontal(false)');
                  var temp = $(".ms-header-notice").is(":visible") ? 88 : 63;
                  $('.ms-anchor-list').scrollToFixed({ 
                    marginTop:63, 
                    top: 0, 
                    limit: $('.ms-header-nav').offset(), 
                    unfixed: function(){
                      if($('body').hasClass('sidenav-active') || $('body').hasClass('buddynav-active')){
                        $(this).css({
                          'position':'fixed',
                          'top': temp
                        });
                      }
                    }
                  }); 
                }
            }
            
        }
        if ($(".ms-nav-horizontal")[0]){ 
            $('.ms-nav-horizontal').trigger('detach.ScrollToFixed');
            if (typeof window.orientation == 'undefined') {  $('.ms-nav-horizontal').scrollToFixed({ marginTop:51, top: 0, limit: $('.ms-header-nav').offset() }); }
        }
        
        if (!$(".ms-hero-home")[0]){ 
            $(".ms-content-main").css("margin","52px 0 0");
        } 
        
        if ($(".ms-breadcrumbs")[0]) {
            $(".ms-content-main").css("margin","52px 0 0");
        }
   } 
}

$(document).ready(function() { 
    $(".ms-header-notice-close").click(function() { noticeC(); });
    bC();
    // Add Date in Footer
    var d = new Date();
    var n = d.getFullYear();
    $(".footerDateYear").html(n);
      $('img').filter(function() {
            return this.src.match(/.*\.svg$/);
        }).each(function(){
        var $img = jQuery(this);
        var imgID = $img.attr('id');
        var imgClass = $img.attr('class');
        var imgURL = $img.attr('src');

        $.get(imgURL, function(data) {
            // Get the SVG tag, ignore the rest
            var $svg = jQuery(data).find('svg');

            // Add replaced image's ID to the new SVG
            if(typeof imgID !== 'undefined') {
                $svg = $svg.attr('id', imgID);
            }
            // Add replaced image's classes to the new SVG
            if(typeof imgClass !== 'undefined') {
                $svg = $svg.attr('class', imgClass+' replaced-svg');
            }

            // Remove any invalid XML tags as per http://validator.w3.org
            $svg = $svg.removeAttr('xmlns:a');

            // Replace image with new SVG
            $img.replaceWith($svg);
        }, 'xml');
    });
        
        $(".anchor-smooth-scroll").click(function(event) {
          event.preventDefault();
          var a = $.attr(this, 'href').replace('#','');
          if(a.length) {
              a = a.replace('#','');
              if ($(window).width() > 984) {
                $('html, body').animate({scrollTop:$(a).offset().top - 140}, 500);
              } else {
                $('html, body').animate({scrollTop:$(a).offset().top - 90}, 500);
              }
            $('.select-location').css('background-color','#f0ffa5'); 
            setTimeout(function () { $('.select-location').css('background-color','#ffffff'); }, 2500);
              return false;
          }
        }); 
    
    $(".anchor-smooth-scroll-footer").click(function(event) {
          event.preventDefault();
          var a = $.attr(this, 'href').replace('#','');
          if(a.length) {
              a = a.replace('#','');
              if ($(window).width() > 984) {
                $('html, body').animate({scrollTop:$(a).offset().top - 140}, 500);
              } else {
                $('html, body').animate({scrollTop:$(a).offset().top - 185}, 500);
              }
         $('.select-location').css('background-color','#f0ffa5'); 
            setTimeout(function () { $('.select-location').css('background-color','#ffffff'); }, 2500);
              return false;
          }
        });
});
$( window ).on( "orientationchange", function( event ) {
    console.log('orientationchange');
  adjustSlideoutHeight();
});
$(window).resize(function() { clearTimeout(cB); cB = setTimeout(bC, 85); });

function bC() { 
    // console.log('bc fired');
    if($(".ms-header-notice").is(":visible")) { noticeO(); } else { noticeC(); }
    if ($(window).width() > 984) { $(".notice-lock-lg").show(); $(".notice-lock-sm").hide(); } else { $(".notice-lock-lg").hide(); $(".notice-lock-sm").show(); }
}

function showAddToCart() {
    $("#add-cart-notification").fadeIn(1000);
    setTimeout(function(){ $("#add-cart-notification").fadeOut(1000) }, 4500);
}

//FUNCTION TO CHECK FOR BANNER PRESENCE
function adjustSlideoutHeight(){
    // console.log('adjusting slideout height');
    // sets offset to 22 if header-notice is present else 0
    // var offset = ($(".ms-header-notice").is(":visible")) ? 22 : 0;
    // if($('#ms-nav-buddy-menu').hasClass('dss-user')){
    //     $('#ms-nav-buddy-menu').css('height',window.innerHeight);
    // }
    // // if header is collapsed - menu is slideout and needs a set height based on window height-offset
    // if($('header').hasClass('collapsed')){
    //     $('#ms-nav-main').css('height',window.innerHeight);
    // }
    // // if header is not collapsed - any inline heights need to be removed
    // else{
    //     $('#ms-nav-main').css('height','');
    // }
}

function noticeGeo() {
                    $('.header-notice-step1').show();
                    $('.header-notice-step2').hide();
                }
 function noticeGeoCookie() {
                    $(".header-notice-step2").show();
                    $(".header-notice-step1").hide();
                }
                function noticeGeoNo() {
                    $(".header-notice-step1").show();
                    $(".header-notice-step2").hide();
                }