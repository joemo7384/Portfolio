'use strict';

msiObj.controllers.nav_search = {
  init: function () {
    var that = this;
    msiObj.data.navSearchOpen = false;
    msiObj.data.navSearchOpenOpenToggle = false;
    var $navSearchToggle = msiObj.utils.getEl('search-toggle', 'id'),
      $tracknode = msiObj.utils.getEl('ms_viewport', 'id'),
      $navSearchInput = msiObj.utils.getEl('nav-search-input', 'id'),
      $navForm = msiObj.utils.getEl('nav-search', 'id'),
      $resultsCont = msiObj.utils.getEl('nav-search-res', 'id'),
      $navGroup = msiObj.utils.getEl('nav-search-g', '.'),
      $navClear = msiObj.utils.getEl('nav-search-clear', 'id'),
      $animSpeed = 400;

    this.navSearchInput = $navSearchInput;
    this.tracknode = $tracknode;
    this.searchToggle = $navSearchToggle;
    this.clearFunc = (Modernizr.input.placeholder) ? this.clearSearch : this.clearSearchIE;
    //Bind event triggers
    msiObj.container.register(this, {
      'sidenav': this.clearFunc,
      'nav-flyout-open': this.closeSearch,
      'buddy-open': this.closeSearch
    });
    // bind the toggle click event
    $navSearchToggle.on('click', function (e) {
      e.preventDefault();
      // choose what to do based on navSearchOpen value
      var toDo = (msiObj.data.navSearchOpen) ? 'removeClass' : 'addClass';
      // check if buddy is open
      var c = $("#ms_viewport").hasClass('ms-nav-buddy-active');
      // if opening search
      // console.log('search open: '+msiObj.data.navSearchOpen);
      if(toDo == 'addClass') {
        // console.log('search ---- addClass');
        //animate in
        $(".ms-search-pane").slideDown(200); 
        $("#nav-search-input").focus();
        // add icon highlighting class 
        $navSearchToggle[toDo]('active');
        //if buddy was open
        if(c){
          // trigger nav_buddy's search-open function closing buddy
          msiObj.container.trigger('search-open');
        }
        //update tracking variable
        msiObj.data.navSearchOpen = true;
      } 
      else { 
        // console.log('search ---- removeClass');
        //$(".ms-search-pane").delay(100).fadeOut(); 
        $("#nav-search-input").blur(); 
        $navSearchToggle[toDo]('active');
        //update tracking variable
        msiObj.data.navSearchOpen = false;
      }
      $tracknode[toDo]('ms-nav-search-active');
      // clear the search field
      that.clearFunc();
      // add or remove the class
      // if no css transitions, animate manually    
      if(!Modernizr.csstransitions) {
        // choose what to do based on navToggle value
        var elPosition = (msiObj.data.navSearchOpenOpenToggle) ? '-70' : '0';
        // animate element
        $navGroup.animate({top:elPosition},{queue:false,duration:$animSpeed});
        // toggle the navToggle Val
        msiObj.data.navSearchOpenOpenToggle = (!msiObj.data.navSearchOpenOpenToggle);
      }
      
    });

    $navClear.on('click', function () {
      that.clearFunc();
    });
      
    // close search box on rotate if tablet or mobile
    if(typeof window.orientation != 'undefined') { window.addEventListener("orientationchange", function() { tabletSearchCloser(); }, false); }
    function tabletSearchCloser() { 
       var s = $("#ms_viewport").hasClass('ms-nav-search-active');  
       var o = window.orientation;
       var s;
       // if portrait
       if (o == 0 || o == 180) { s = $("#ms_viewport").hasClass('ms-nav-search-active'); if (s) { $('#nav_search_toggle').trigger('click'); }}
    }

    // bind form submit on enter key
    $navSearchInput.on('keypress', function (e) {
      if (e.keyCode == 13) {
        $navForm.submit();
      }
    });
  
    if(!Modernizr.input.placeholder){
      this.navSearchInput.focus(function() {
        var input = $(this);
        if (input.val() == input.attr('placeholder')) {
          input.val('');
          input.removeClass('placeholder');
        }
      }).blur(function() {
        if (that.navSearchInput.val() == '' || that.navSearchInput.val() == that.navSearchInput.attr('placeholder')) {
          that.clearSearchIE();
        }
      }).blur();
      this.navSearchInput.parents('form').submit(function() {
        $(this).find('[placeholder]').each(function() {
          var input = $(this);
          if (input.val() == input.attr('placeholder')) {
            input.val('');
          }
        })
      });
    }
  },
  clearSearchIE: function () {
    this.navSearchInput.addClass('placeholder');
    this.navSearchInput.val(this.navSearchInput.attr('placeholder'));
  },
  clearSearch: function () {
   this.navSearchInput.val('');
  },
  closeSearch: function (vals) {
    // console.log('nav_search -- closeSearch');
    if(this.tracknode.hasClass('ms-nav-search-active')){
      this.clearFunc();
      //set navBuddyOpen Val to false because it is closing
      msiObj.data.navSearchOpen = (false);
      // Remove the class for icon highlighting
      this.searchToggle.removeClass('active');
      // Remove tracking class from viewport
      this.tracknode.removeClass('ms-nav-search-active'); 
    }
  }
}