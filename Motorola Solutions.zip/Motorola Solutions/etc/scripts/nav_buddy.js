'use strict';

msiObj.controllers.nav_login = {
  init: function () {
    var that = this;
    msiObj.data.navBuddyOpen = false;
    msiObj.data.navBuddyOpenToggle = false;
    var $navBuddyToggle = msiObj.utils.getEl('buddy-toggle', 'id'),
      // SWAPPED TO ALLOW IN BROWSER STATUS CHANGE
      // $userStatus = $navBuddyToggle.data('user-status'),
      $buddyContent = msiObj.utils.getEl('ms-nav-buddy-menu', 'id'),
      $tracknode = msiObj.utils.getEl('ms_viewport', 'id'),
      $navLoginInput = msiObj.utils.getEl('nav-login-input', 'id'),
      $navForm = msiObj.utils.getEl('nav-login', 'id'),
      $resultsCont = msiObj.utils.getEl('nav-login-res', 'id'),
      $navLoginGroup = msiObj.utils.getEl('nav-login-g', '.'),
      $navClear = msiObj.utils.getEl('nav-login-clear', 'id'),
      $animSpeed = 400;

    this.navLoginInput = $navLoginInput;
    this.tracknode = $tracknode;
    this.buddyToggle = $navBuddyToggle;
    this.clearFunc = (Modernizr.input.placeholder) ? this.clearSearch : this.clearSearchIE;
    //Bind event triggers
    msiObj.container.register(this, {
      'sidenav': this.clearFunc,
      'nav-flyout-open': this.closeBuddy,
      'search-open' : this.closeBuddy
    });
    //Attach click listener to buddy toggle
    $navBuddyToggle.on('click', function (e) {
      e.preventDefault();
        // console.log($userStatus);
      var c = $tracknode.hasClass('ms-nav-search-active');
      //if dss user

      // SWAPPED TO ALLOW IN BROWSER STATUS CHANGE
      // if($userStatus === 'dss_user'){
        if($(this).data('user-status') === 'dss_user'){
        // console.log('dss_user');
          //set height of slide out to full height
          $buddyContent.css('height',window.innerHeight);
          //trigger it open
          msiObj.container.trigger('sidenav', [!msiObj.data.sidenav,'buddynav']);
          if(c){
            //trigger nav_search's buddy open function closing search
            msiObj.container.trigger('buddy-open');
          }
      }
      //else if default user
      else{
        // console.log('default user');
        // choose what to do based on if buddy slide out is open or not
        var toDo = (msiObj.data.navBuddyOpen) ? 'removeClass' : 'addClass';
        // check if search is open
        // if opening buddy
        // console.log('buddy open: '+msiObj.data.navBuddyOpen);
        if(toDo == 'addClass') {
          // console.log('buddy ---- addClass');
          //fade in and add active class for icon highlighting
          $(".default-user").fadeIn(400);
          $navBuddyToggle[toDo]('active');
          //if search was open
          if(c){
            //trigger nav_search's buddy open function closing search
            msiObj.container.trigger('buddy-open');
          }
          //update tracking variable
          msiObj.data.navBuddyOpen = true;
        }
        else{
          // console.log('buddy ---- removeClass');
          //set navBuddyOpen Val to false because it is closing
          msiObj.data.navBuddyOpen = (false);
          // Remove the class for icon highlighting
          $navBuddyToggle.removeClass('active');
          // Remove tracking class from viewport
          $tracknode.removeClass('ms-nav-buddy-active');
          // Fade out the buddy menu
          $(".default-user").fadeOut(200); 
          //update tracking variable
          msiObj.data.navBuddyOpen = false;
        } 
        // add or remove tracking class to viewport
        $tracknode[toDo]('ms-nav-buddy-active');  
        // clear the login field
        that.clearFunc();
        // if no css transitions, animate manually    
        if(!Modernizr.csstransitions) {
          // choose what to do based on navLoginToggle value
          var elLoginPosition = (msiObj.data.navBuddyOpenToggle) ? '-156' : '0';
          // animate element
          $navLoginGroup.animate({top:elLoginPosition},{queue:false,duration:$animSpeed});
          // toggle the navLoginToggle Val
          msiObj.data.navBuddyOpenToggle = (!msiObj.data.navBuddyOpenToggle);
        }
      }
      // if(($('.ms-nav-search-active')[0])) { $("#search-toggle").click(); }
    });

    $navClear.on('click', function () {
      that.clearFunc();
    });
      
    // close login box on rotate if tablet or mobile
  if(typeof window.orientation != 'undefined') { window.addEventListener("orientationchange", function() { tabletLoginCloser();  }, false); }
    function tabletLoginCloser() { 
       var s = $("#ms_viewport").hasClass('ms-nav-login-active'); 
       var o = window.orientation;
       var s;
    }
   function cL() { 
        if ($(window).width() < 984) {
          var cM = $("#ms_viewport").hasClass('ms-nav-buddy-active');
          // console.log('nav_buddy -- cL');
          if (cM) { $('#nav_login_toggle').trigger('click'); }
              // $(".nav-login").insertAfter($('.ms-nav-util'));
              $(".ms-login-pane").fadeIn(200);
           } else { 
              // $(".nav-login").insertBefore($('.nav-search'));
              $(".ms-login-pane").fadeOut(200);
           }
    }
    var lT; 
    $(window).resize(function() { clearTimeout(lT); lT = setTimeout(cL, 85); });
        $(document).ready(function(){ cL(); });
    

    // bind form submit on enter key
    $navLoginInput.on('keypress', function (e) {
      if (e.keyCode == 13) {
        $navForm.submit();
      }
    });
  
    if(!Modernizr.input.placeholder){
      this.navLoginInput.focus(function() {
        var input = $(this);
        if (input.val() == input.attr('placeholder')) {
          input.val('');
          input.removeClass('placeholder');
        }
      }).blur(function() {
        if (that.navLoginInput.val() == '' || that.navLoginInput.val() == that.navLoginInput.attr('placeholder')) {
          that.clearSearchIE();
        }
      }).blur();
      this.navLoginInput.parents('form').submit(function() {
        $(this).find('[placeholder]').each(function() {
          var input = $(this);
          if (input.val() == input.attr('placeholder')) {
            input.val('');
          }
        })
      });
    }
  },
  clearSearchIE: function () {
    this.navLoginInput.addClass('placeholder');
    this.navLoginInput.val(this.navLoginInput.attr('placeholder'));
  },
  clearSearch: function () {
   this.navLoginInput.val('');
  },
  closeBuddy: function (vals) {
    // console.log('nav_buddy -- closeBuddy');
    // check if tracking class is attached to viewport indicating buddy open
    if(this.tracknode.hasClass('ms-nav-buddy-active')){
      this.clearFunc();
      //set navBuddyOpen Val to false because it is closing
      msiObj.data.navBuddyOpen = (false);
      // Remove the class for icon highlighting
      this.buddyToggle.removeClass('active');
      // Remove tracking class from viewport
      this.tracknode.removeClass('ms-nav-buddy-active');
      // Fade out the buddy menu
      $(".default-user").fadeOut(200); 
    }
  }
}