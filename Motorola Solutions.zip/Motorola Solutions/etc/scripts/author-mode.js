function authorNav() {
    document.getElementById('ContentFrame').contentWindow.location.reload(true);
}
$(document).on('load', function(){
    setTimeout('authorNav()', 150);
});
$('.toggle-sidepanel').click(function(){
    setTimeout('authorNav()', 500);
});